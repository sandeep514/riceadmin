$(function(){

})(jQuery);
